import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registrationForm: FormGroup;
  submitted = false;
  successMessage: string = '';  // New variable for success message

  constructor(
    private fb: FormBuilder,
    private router: Router
  ) {
    this.registrationForm = this.fb.group({
      firstName: ['', [Validators.required, Validators.minLength(3), this.noThreeSameConsecutiveChars]],
      lastName: ['', [Validators.required, Validators.minLength(3), this.noThreeSameConsecutiveChars]],
      email: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9._%+-]+@gmail.com$')]],
      password: ['', [Validators.required, Validators.pattern('^(?=.*[!@#$%^&*])[A-Za-z0-9!@#$%^&*]{6,}$')]],
      dateOfBirth: ['', [Validators.required, this.noFutureDate]]
    });
  }

  ngOnInit(): void { }

  onSubmit(): void {
    this.submitted = true;
    if (this.registrationForm.valid) {
      // Logic for registration (e.g., API call) can go here

      // Set success message when registration is successful
      this.successMessage = 'Registration Successful! Please proceed to log in.';

      // Optional: Redirect to login page after a short delay
      setTimeout(() => this.router.navigate(['/login']), 3000);
    }
  }

  // Custom validator for date
  noFutureDate(control: any) {
    const today = new Date().toISOString().split('T')[0];
    return control.value > today ? { futureDate: true } : null;
  }

  // Custom validator to prevent 3 consecutive same characters
  noThreeSameConsecutiveChars(control: any) {
    const value = control.value;
    if (/(\w)\1\1/.test(value)) {
      return { sameChars: true };
    }
    return null;
  }
}
