import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  employeeId: string = '';
  password: string = '';
  loginError: string = '';
  loginMessage: string = ''; // New variable to store success message

  // Predefined credentials
  predefinedEmployeeId = 'emp@gmail.com';
  predefinedPassword = 'password123';

  constructor(private router: Router) { }

  onLogin(): void {
    // Check if the employeeId and password match the predefined credentials
    if (this.employeeId === this.predefinedEmployeeId && this.password === this.predefinedPassword) {
      this.loginError = '';
      this.loginMessage = 'Login Successful'; // Set success message
      alert('Login Successful'); // Optional: Show browser alert as well
      this.router.navigate(['/home']);
    } else {
      this.loginError = 'Invalid Employee ID or Password';
      this.loginMessage = ''; // Clear success message if login fails
    }
  }
}
