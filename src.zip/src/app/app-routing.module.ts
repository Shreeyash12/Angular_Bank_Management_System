import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';  // Add LoginComponent import

const routes: Routes = [
  { path: '', component: HomeComponent }, // Default home route
  { path: 'home', component: HomeComponent }, // Home route
  { path: 'register', component: RegisterComponent }, // Registration route
  { path: 'login', component: LoginComponent } // Login route
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
